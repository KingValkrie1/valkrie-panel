# WA AI Bot Multifungsi

Bot WhatsApp berbasis [Baileys](https://github.com/WhiskeySockets/Baileys) (tidak perlu WhatsApp Business API resmi, login via scan QR).

## Fitur
- 🧠 Chat dengan AI (`.ai`), OpenAI-compatible — bisa pakai OpenAI, Groq, OpenRouter, DeepSeek, dll
- 🖼️ Buat stiker dari gambar/video (`.sticker`) dan sebaliknya (`.toimg`)
- 🌐 Terjemahan teks (`.tr`)
- 🧮 Kalkulator (`.calc`)
- 💬 Kutipan motivasi acak (`.quote`)
- 🏓 Ping/cek status (`.ping`)
- 📋 Menu bantuan (`.menu`)
- Mudah ditambah command baru (lihat bagian "Menambah Command")

## Instalasi

1. Pastikan Node.js versi 18 ke atas sudah terpasang.
2. Extract folder ini, lalu masuk ke dalamnya:
   ```
   cd wa-ai-bot
   npm install
   ```
3. Salin `.env.example` menjadi `.env`, lalu isi `AI_API_KEY` dengan API key kamu (OpenAI/Groq/OpenRouter/dll):
   ```
   cp .env.example .env
   ```
4. Jalankan bot:
   ```
   npm start
   ```
5. Scan QR code yang muncul di terminal menggunakan WhatsApp di HP kamu:
   **WhatsApp > Perangkat Tertaut > Tautkan Perangkat**.
6. Setelah terhubung, coba kirim `.menu` ke chat pribadi bot (nomor yang login) atau ke grup yang berisi bot.

Sesi login akan tersimpan di folder `auth_info/` sehingga tidak perlu scan ulang setiap kali dijalankan (kecuali kamu logout dari HP atau hapus folder tersebut).

## Menambah Command Baru

1. Buat file baru di folder `commands/`, contoh `commands/cuaca.js`:
   ```js
   module.exports = {
     name: 'cuaca',
     aliases: [],
     description: 'Cek cuaca kota tertentu',
     async execute({ sock, msg, args }) {
       await sock.sendMessage(msg.key.remoteJid, { text: 'Fitur cuaca segera hadir!' }, { quoted: msg });
     },
   };
   ```
2. Import dan daftarkan di `index.js`, tambahkan ke array `commands`.
3. Restart bot.

## Catatan Penting
- Baileys adalah library tidak resmi. Gunakan dengan wajar (jangan spam massal) agar nomor tidak diblokir WhatsApp.
- Untuk pemakaian produksi/skala besar, pertimbangkan WhatsApp Business Cloud API resmi dari Meta.
- Ganti `AI_BASE_URL` dan `AI_MODEL` di `.env` sesuai provider AI yang kamu pakai.
