require('dotenv').config();

module.exports = {
  prefix: process.env.PREFIX || '.',
  ownerName: process.env.OWNER_NAME || 'Owner',
  ownerNumber: process.env.OWNER_NUMBER || '',
  ai: {
    apiKey: process.env.AI_API_KEY || '',
    baseUrl: process.env.AI_BASE_URL || 'https://api.openai.com/v1',
    model: process.env.AI_MODEL || 'gpt-4o-mini',
  },
};
