const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const qrcode = require('qrcode-terminal');

const config = require('./config');
const menuCommand = require('./commands/menu');
const aiCommand = require('./commands/ai');
const stickerCommand = require('./commands/sticker');
const translateCommand = require('./commands/translate');
const { pingCommand, calcCommand, quoteCommand, ownerCommand } = require('./commands/tools');

// Daftarkan semua command di sini. Tambah command baru cukup push ke array ini.
const commands = [
  menuCommand,
  aiCommand,
  aiCommand.resetCommand,
  stickerCommand,
  stickerCommand.toImgCommand,
  translateCommand,
  pingCommand,
  calcCommand,
  quoteCommand,
  ownerCommand,
];

const commandMap = new Map();
for (const cmd of commands) {
  commandMap.set(cmd.name, cmd);
  for (const alias of cmd.aliases || []) commandMap.set(alias, cmd);
}

function extractText(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    ''
  );
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log('Scan QR code berikut dengan WhatsApp kamu:');
      qrcode.generate(qr, { small: true });
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log('Koneksi terputus.', shouldReconnect ? 'Menyambung ulang...' : 'Logout, hapus folder auth_info untuk login ulang.');
      if (shouldReconnect) startBot();
    } else if (connection === 'open') {
      console.log('✅ Bot berhasil terhubung ke WhatsApp!');
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const text = extractText(msg).trim();
    if (!text.startsWith(config.prefix)) return;

    const withoutPrefix = text.slice(config.prefix.length).trim();
    const [cmdName, ...args] = withoutPrefix.split(/\s+/);
    const command = commandMap.get(cmdName.toLowerCase());
    if (!command) return;

    const sender = msg.key.participant || msg.key.remoteJid;

    try {
      await command.execute({ sock, msg, args, sender });
    } catch (err) {
      console.error(`Error menjalankan command ${cmdName}:`, err);
      await sock.sendMessage(
        msg.key.remoteJid,
        { text: `❌ Terjadi kesalahan saat menjalankan perintah: ${err.message}` },
        { quoted: msg }
      );
    }
  });
}

startBot();
