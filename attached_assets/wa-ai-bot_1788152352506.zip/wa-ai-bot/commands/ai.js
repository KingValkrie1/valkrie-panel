const { askAI, resetHistory } = require('../lib/aiClient');

module.exports = {
  name: 'ai',
  aliases: ['ask', 'gpt'],
  description: 'Ngobrol dengan AI',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const question = args.join(' ').trim();

    if (!question) {
      await sock.sendMessage(
        chatId,
        { text: 'Tulis pertanyaannya juga ya, contoh:\n.ai jelaskan apa itu fotosintesis' },
        { quoted: msg }
      );
      return;
    }

    await sock.sendPresenceUpdate('composing', chatId);
    try {
      const reply = await askAI(chatId, question);
      await sock.sendMessage(chatId, { text: reply }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(
        chatId,
        { text: `❌ Gagal menghubungi AI: ${err.message}` },
        { quoted: msg }
      );
    }
  },
};

module.exports.resetCommand = {
  name: 'resetai',
  aliases: ['clearai'],
  description: 'Reset riwayat obrolan AI di chat ini',
  async execute({ sock, msg }) {
    resetHistory(msg.key.remoteJid);
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: '✅ Riwayat obrolan AI di chat ini sudah direset.' },
      { quoted: msg }
    );
  },
};
