const config = require('../config');

module.exports = {
  name: 'menu',
  aliases: ['help'],
  description: 'Menampilkan daftar perintah',
  async execute({ sock, msg, sender }) {
    const p = config.prefix;
    const text = `🤖 *WA AI BOT*
Halo! Berikut daftar perintah yang tersedia:

*🧠 AI*
${p}ai <pertanyaan> - Ngobrol dengan AI
${p}resetai - Reset riwayat obrolan AI

*🛠️ Utilitas*
${p}sticker (kirim/reply gambar atau video pendek) - Buat stiker
${p}toimg (reply stiker) - Ubah stiker jadi gambar
${p}tr <kode_bahasa> <teks> - Terjemahkan teks (contoh: ${p}tr en halo semua)
${p}calc <ekspresi> - Kalkulator (contoh: ${p}calc 12*7-3)
${p}quote - Kutipan acak
${p}ping - Cek kecepatan respons bot

*ℹ️ Info*
${p}owner - Info pemilik bot
${p}menu - Menampilkan menu ini

Kirim perintah tanpa spasi ekstra, prefix: "${p}"`;
    await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
  },
};
