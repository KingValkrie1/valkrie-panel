const translate = require('@vitalets/google-translate-api');

module.exports = {
  name: 'tr',
  aliases: ['translate'],
  description: 'Terjemahkan teks. Contoh: .tr en halo semua',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;

    if (args.length < 2) {
      await sock.sendMessage(
        chatId,
        { text: 'Format: .tr <kode_bahasa_tujuan> <teks>\nContoh: .tr en Selamat pagi semua' },
        { quoted: msg }
      );
      return;
    }

    const targetLang = args[0];
    const text = args.slice(1).join(' ');

    try {
      const result = await translate(text, { to: targetLang });
      await sock.sendMessage(
        chatId,
        { text: `🌐 *Hasil terjemahan (${targetLang}):*\n${result.text}` },
        { quoted: msg }
      );
    } catch (err) {
      await sock.sendMessage(
        chatId,
        { text: `❌ Gagal menerjemahkan: ${err.message}` },
        { quoted: msg }
      );
    }
  },
};
