const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

function getQuotedOrDirectMedia(msg) {
  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (quoted?.imageMessage || quoted?.videoMessage) {
    return {
      message: quoted,
      key: {
        ...msg.key,
        id: msg.message.extendedTextMessage.contextInfo.stanzaId,
      },
    };
  }
  if (msg.message?.imageMessage || msg.message?.videoMessage) {
    return msg;
  }
  return null;
}

module.exports = {
  name: 'sticker',
  aliases: ['s', 'stiker'],
  description: 'Ubah gambar/video pendek jadi stiker',
  async execute({ sock, msg }) {
    const chatId = msg.key.remoteJid;
    const target = getQuotedOrDirectMedia(msg);

    if (!target) {
      await sock.sendMessage(
        chatId,
        { text: 'Kirim gambar/video (atau reply gambar/video) dengan caption .sticker' },
        { quoted: msg }
      );
      return;
    }

    try {
      const buffer = await downloadMediaMessage(target, 'buffer', {});
      const sticker = new Sticker(buffer, {
        pack: 'WA AI Bot',
        author: 'Kamu',
        type: StickerTypes.FULL,
        quality: 70,
      });
      const stickerBuffer = await sticker.toBuffer();
      await sock.sendMessage(chatId, { sticker: stickerBuffer }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(
        chatId,
        { text: `❌ Gagal membuat stiker: ${err.message}` },
        { quoted: msg }
      );
    }
  },
};

module.exports.toImgCommand = {
  name: 'toimg',
  aliases: ['toimage'],
  description: 'Ubah stiker jadi gambar (reply stiker)',
  async execute({ sock, msg }) {
    const chatId = msg.key.remoteJid;
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!quoted?.stickerMessage) {
      await sock.sendMessage(chatId, { text: 'Reply sebuah stiker dengan caption .toimg' }, { quoted: msg });
      return;
    }

    try {
      const target = {
        message: quoted,
        key: {
          ...msg.key,
          id: msg.message.extendedTextMessage.contextInfo.stanzaId,
        },
      };
      const buffer = await downloadMediaMessage(target, 'buffer', {});
      await sock.sendMessage(chatId, { image: buffer }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal mengonversi: ${err.message}` }, { quoted: msg });
    }
  },
};
