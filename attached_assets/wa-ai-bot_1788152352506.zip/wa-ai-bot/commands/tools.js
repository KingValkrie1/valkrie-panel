const config = require('../config');

const quotes = [
  'Kesuksesan adalah kumpulan dari usaha-usaha kecil yang diulang setiap hari.',
  'Jangan tunggu waktu yang tepat, ciptakan waktu itu sendiri.',
  'Kegagalan hanyalah kesempatan untuk memulai lagi dengan lebih cerdas.',
  'Langkah pertama selalu yang paling sulit, tapi juga yang paling penting.',
  'Fokus pada progres, bukan kesempurnaan.',
];

const pingCommand = {
  name: 'ping',
  aliases: [],
  description: 'Cek kecepatan respons bot',
  async execute({ sock, msg }) {
    const start = Date.now();
    const sent = await sock.sendMessage(msg.key.remoteJid, { text: '🏓 Menghitung...' }, { quoted: msg });
    const latency = Date.now() - start;
    await sock.sendMessage(
      msg.key.remoteJid,
      { text: `🏓 Pong! ${latency}ms`, edit: sent.key },
    );
  },
};

const calcCommand = {
  name: 'calc',
  aliases: ['hitung'],
  description: 'Kalkulator sederhana',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const expr = args.join(' ');

    if (!expr) {
      await sock.sendMessage(chatId, { text: 'Contoh: .calc 12*7-3' }, { quoted: msg });
      return;
    }

    // Hanya izinkan karakter angka & operator dasar demi keamanan (no eval bebas)
    if (!/^[0-9+\-*/().\s]+$/.test(expr)) {
      await sock.sendMessage(chatId, { text: '❌ Ekspresi tidak valid, hanya angka dan + - * / ( )' }, { quoted: msg });
      return;
    }

    try {
      // eslint-disable-next-line no-new-func
      const result = Function(`"use strict"; return (${expr})`)();
      await sock.sendMessage(chatId, { text: `🧮 Hasil: ${result}` }, { quoted: msg });
    } catch {
      await sock.sendMessage(chatId, { text: '❌ Gagal menghitung, cek lagi ekspresinya.' }, { quoted: msg });
    }
  },
};

const quoteCommand = {
  name: 'quote',
  aliases: ['kutipan'],
  description: 'Kutipan motivasi acak',
  async execute({ sock, msg }) {
    const q = quotes[Math.floor(Math.random() * quotes.length)];
    await sock.sendMessage(msg.key.remoteJid, { text: `💬 "${q}"` }, { quoted: msg });
  },
};

const ownerCommand = {
  name: 'owner',
  aliases: [],
  description: 'Info pemilik bot',
  async execute({ sock, msg }) {
    const text = `👤 *Owner Bot*\nNama: ${config.ownerName}\nNomor: ${config.ownerNumber || '(belum diatur)'}`;
    await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
  },
};

module.exports = { pingCommand, calcCommand, quoteCommand, ownerCommand };
