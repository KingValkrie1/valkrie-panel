const { parseWaktu } = require('../lib/timeParser');
const scheduler = require('../lib/scheduler');

const DAY_NAMES_ID = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

function formatDate(date) {
  return new Date(date).toLocaleString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

module.exports = {
  name: 'jadwal',
  aliases: ['schedule', 'ingatkanbesok'],
  description: 'Jadwalkan pesan/pengingat. Contoh: .jadwal besok jam 8 | minum obat',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    const fullArgs = args.join(' ');

    if (!fullArgs || fullArgs.toLowerCase() === 'list') {
      const list = scheduler.listSchedules(chatId);
      if (list.length === 0) {
        await sock.sendMessage(
          chatId,
          {
            text:
              'Belum ada jadwal aktif di chat ini.\n\nCara pakai:\n.jadwal <waktu> | <pesan>\n\nContoh:\n.jadwal besok jam 8 | meeting sama klien\n.jadwal 3 jam lagi | angkat jemuran\n.jadwal setiap hari jam 6 | sholat subuh\n.jadwal senin jam 9 | mulai kerja\n.jadwal 31/12 jam 20:00 | tahun baruan\n\nLihat jadwal: .jadwal list\nBatalkan: .jadwal hapus <id>',
          },
          { quoted: msg }
        );
        return;
      }
      const text = `📅 *Jadwal aktif di chat ini:*\n\n${list
        .map(
          (j, i) =>
            `${i + 1}. [id: ${j.id}]\n"${j.message}"\n🕐 ${formatDate(j.nextRun)}${
              j.recurring ? ` (berulang ${j.recurring === 'daily' ? 'setiap hari' : 'setiap minggu'})` : ''
            }`
        )
        .join('\n\n')}`;
      await sock.sendMessage(chatId, { text }, { quoted: msg });
      return;
    }

    if (fullArgs.toLowerCase().startsWith('hapus ')) {
      const id = fullArgs.split(/\s+/)[1];
      const ok = scheduler.cancelSchedule(id, chatId);
      await sock.sendMessage(
        chatId,
        { text: ok ? `✅ Jadwal ${id} dibatalkan.` : `❌ Jadwal dengan id "${id}" tidak ditemukan.` },
        { quoted: msg }
      );
      return;
    }

    const [waktuPart, ...pesanParts] = fullArgs.split('|');
    const pesan = pesanParts.join('|').trim();

    if (!pesan) {
      await sock.sendMessage(
        chatId,
        { text: 'Format: .jadwal <waktu> | <pesan>\nContoh: .jadwal besok jam 8 | minum obat' },
        { quoted: msg }
      );
      return;
    }

    const result = parseWaktu(waktuPart.trim());
    if (result.error) {
      await sock.sendMessage(chatId, { text: `❌ ${result.error}` }, { quoted: msg });
      return;
    }

    const job = scheduler.addSchedule({
      chatId,
      senderId: sender,
      message: pesan,
      date: result.date,
      recurring: result.recurring,
      dayOfWeek: result.dayOfWeek,
    });

    const recurText = result.recurring
      ? ` (akan berulang ${result.recurring === 'daily' ? 'setiap hari' : 'setiap minggu'})`
      : '';

    await sock.sendMessage(
      chatId,
      {
        text: `✅ Jadwal dibuat!\n"${pesan}"\n🕐 ${formatDate(job.nextRun)}${recurText}\n🆔 id: ${job.id} (dipakai untuk .jadwal hapus ${job.id})`,
      },
      { quoted: msg }
    );
  },
};
