const db = require('../lib/db');
const { requireGroupAdmin } = require('./groupadmin');

const MAX_WARN = 3;

function getWarns(chatId) {
  const all = db.read('warns', {});
  return all[chatId] || {};
}

function saveWarns(chatId, warns) {
  const all = db.read('warns', {});
  all[chatId] = warns;
  db.write('warns', all);
}

function getMentionedOrRepliedUser(msg) {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mentioned && mentioned.length > 0) return mentioned[0];
  const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (quotedParticipant) return quotedParticipant;
  return null;
}

const warnCommand = {
  name: 'warn',
  aliases: ['peringatan'],
  description: '[Admin] Beri peringatan ke anggota (reply/mention). 3x warn = auto-kick',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;

    const target = getMentionedOrRepliedUser(msg);
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Reply atau mention orang yang mau di-warn. Contoh: .warn (reply) telat terus' }, { quoted: msg });
      return;
    }

    const reason = args.join(' ').trim() || '(tanpa alasan)';
    const warns = getWarns(chatId);
    warns[target] = (warns[target] || 0) + 1;
    saveWarns(chatId, warns);

    if (warns[target] >= MAX_WARN) {
      delete warns[target];
      saveWarns(chatId, warns);
      try {
        await sock.groupParticipantsUpdate(chatId, [target], 'remove');
        await sock.sendMessage(chatId, {
          text: `🚫 @${target.split('@')[0]} sudah mencapai ${MAX_WARN}x peringatan dan dikeluarkan dari grup.`,
          mentions: [target],
        });
      } catch {
        await sock.sendMessage(chatId, {
          text: `⚠️ @${target.split('@')[0]} sudah mencapai ${MAX_WARN}x peringatan tapi bot gagal mengeluarkan (pastikan bot admin).`,
          mentions: [target],
        });
      }
    } else {
      await sock.sendMessage(chatId, {
        text: `⚠️ @${target.split('@')[0]} mendapat peringatan (${warns[target]}/${MAX_WARN})\nAlasan: ${reason}`,
        mentions: [target],
      });
    }
  },
};

const resetWarnCommand = {
  name: 'resetwarn',
  aliases: ['hapuswarn'],
  description: '[Admin] Reset peringatan seseorang (reply/mention)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const target = getMentionedOrRepliedUser(msg);
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Reply atau mention orangnya.' }, { quoted: msg });
      return;
    }
    const warns = getWarns(chatId);
    delete warns[target];
    saveWarns(chatId, warns);
    await sock.sendMessage(chatId, { text: `✅ Peringatan untuk @${target.split('@')[0]} direset.`, mentions: [target] }, { quoted: msg });
  },
};

module.exports = { warnCommand, resetWarnCommand };
