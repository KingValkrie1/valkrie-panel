const db = require('../lib/db');
const { requireGroupAdmin } = require('./groupadmin');

function getConfig(chatId) {
  const all = db.read('welcome_config', {});
  return all[chatId] || {};
}

function saveConfig(chatId, cfg) {
  const all = db.read('welcome_config', {});
  all[chatId] = cfg;
  db.write('welcome_config', all);
}

const setWelcomeCommand = {
  name: 'setwelcome',
  aliases: [],
  description: '[Admin] Atur pesan selamat datang. Pakai {user} dan {group}. .setwelcome off untuk matikan',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const text = args.join(' ').trim();
    const cfg = getConfig(chatId);

    if (text.toLowerCase() === 'off') {
      cfg.welcome = null;
      saveConfig(chatId, cfg);
      await sock.sendMessage(chatId, { text: '✅ Pesan selamat datang custom dimatikan (pakai default).' }, { quoted: msg });
      return;
    }
    if (!text) {
      await sock.sendMessage(
        chatId,
        { text: 'Contoh: .setwelcome Halo {user}, selamat datang di {group}! Baca dulu deskripsi grup ya.\n\nMatikan: .setwelcome off' },
        { quoted: msg }
      );
      return;
    }
    cfg.welcome = text;
    saveConfig(chatId, cfg);
    await sock.sendMessage(chatId, { text: '✅ Pesan selamat datang disimpan.' }, { quoted: msg });
  },
};

const setGoodbyeCommand = {
  name: 'setgoodbye',
  aliases: [],
  description: '[Admin] Atur pesan perpisahan. Pakai {user} dan {group}. .setgoodbye off untuk matikan',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const text = args.join(' ').trim();
    const cfg = getConfig(chatId);

    if (text.toLowerCase() === 'off') {
      cfg.goodbye = null;
      saveConfig(chatId, cfg);
      await sock.sendMessage(chatId, { text: '✅ Pesan perpisahan custom dimatikan (pakai default).' }, { quoted: msg });
      return;
    }
    if (!text) {
      await sock.sendMessage(
        chatId,
        { text: 'Contoh: .setgoodbye Selamat tinggal {user}, sampai jumpa lagi!\n\nMatikan: .setgoodbye off' },
        { quoted: msg }
      );
      return;
    }
    cfg.goodbye = text;
    saveConfig(chatId, cfg);
    await sock.sendMessage(chatId, { text: '✅ Pesan perpisahan disimpan.' }, { quoted: msg });
  },
};

module.exports = { setWelcomeCommand, setGoodbyeCommand, getConfig };
