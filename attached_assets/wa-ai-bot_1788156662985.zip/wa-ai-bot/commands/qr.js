const QRCode = require('qrcode');

module.exports = {
  name: 'qr',
  aliases: ['qrcode'],
  description: 'Buat gambar QR code dari teks/link. Contoh: .qr https://wa.me/6281234567890',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const text = args.join(' ').trim();

    if (!text) {
      await sock.sendMessage(chatId, { text: 'Contoh: .qr https://example.com' }, { quoted: msg });
      return;
    }

    try {
      const buffer = await QRCode.toBuffer(text, { width: 512, margin: 1 });
      await sock.sendMessage(chatId, { image: buffer, caption: `📱 QR code untuk: ${text}` }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal membuat QR code: ${err.message}` }, { quoted: msg });
    }
  },
};
