async function isSenderAdmin(sock, chatId, sender) {
  const metadata = await sock.groupMetadata(chatId);
  const participant = metadata.participants.find((p) => p.id === sender);
  return participant?.admin === 'admin' || participant?.admin === 'superadmin';
}

async function isBotAdmin(sock, chatId) {
  const metadata = await sock.groupMetadata(chatId);
  const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
  const botParticipant = metadata.participants.find((p) => p.id.startsWith(sock.user.id.split(':')[0]));
  return botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
}

function getMentionedOrRepliedUser(msg) {
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mentioned && mentioned.length > 0) return mentioned[0];
  const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
  if (quotedParticipant) return quotedParticipant;
  return null;
}

const tagallCommand = {
  name: 'tagall',
  aliases: ['everyone'],
  description: 'Mention semua anggota grup (khusus grup)',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini hanya bisa dipakai di grup.' }, { quoted: msg });
      return;
    }

    const metadata = await sock.groupMetadata(chatId);
    const participants = metadata.participants.map((p) => p.id);
    const note = args.join(' ') || 'Panggilan untuk semua anggota grup';

    const text = `📢 *Tag All*\n${note}\n\n${participants.map((p) => `@${p.split('@')[0]}`).join(' ')}`;
    await sock.sendMessage(chatId, { text, mentions: participants }, { quoted: msg });
  },
};

const kickCommand = {
  name: 'kick',
  aliases: ['tendang'],
  description: 'Keluarkan anggota dari grup (reply/mention orangnya, khusus admin)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini hanya bisa dipakai di grup.' }, { quoted: msg });
      return;
    }
    if (!(await isSenderAdmin(sock, chatId, sender))) {
      await sock.sendMessage(chatId, { text: '❌ Hanya admin grup yang bisa pakai perintah ini.' }, { quoted: msg });
      return;
    }
    if (!(await isBotAdmin(sock, chatId))) {
      await sock.sendMessage(chatId, { text: '❌ Bot harus jadi admin dulu untuk bisa mengeluarkan anggota.' }, { quoted: msg });
      return;
    }

    const target = getMentionedOrRepliedUser(msg);
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Reply atau mention orang yang mau dikeluarkan.' }, { quoted: msg });
      return;
    }

    await sock.groupParticipantsUpdate(chatId, [target], 'remove');
    await sock.sendMessage(chatId, { text: `✅ Berhasil mengeluarkan @${target.split('@')[0]}`, mentions: [target] });
  },
};

const promoteCommand = {
  name: 'promote',
  aliases: ['jadikanadmin'],
  description: 'Jadikan anggota sebagai admin (reply/mention orangnya, khusus admin)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) return;
    if (!(await isSenderAdmin(sock, chatId, sender))) {
      await sock.sendMessage(chatId, { text: '❌ Hanya admin grup yang bisa pakai perintah ini.' }, { quoted: msg });
      return;
    }
    const target = getMentionedOrRepliedUser(msg);
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Reply atau mention orang yang mau dijadikan admin.' }, { quoted: msg });
      return;
    }
    await sock.groupParticipantsUpdate(chatId, [target], 'promote');
    await sock.sendMessage(chatId, { text: `✅ @${target.split('@')[0]} sekarang jadi admin`, mentions: [target] });
  },
};

const demoteCommand = {
  name: 'demote',
  aliases: ['turunkanadmin'],
  description: 'Turunkan admin jadi anggota biasa (reply/mention orangnya, khusus admin)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) return;
    if (!(await isSenderAdmin(sock, chatId, sender))) {
      await sock.sendMessage(chatId, { text: '❌ Hanya admin grup yang bisa pakai perintah ini.' }, { quoted: msg });
      return;
    }
    const target = getMentionedOrRepliedUser(msg);
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Reply atau mention orang yang mau diturunkan.' }, { quoted: msg });
      return;
    }
    await sock.groupParticipantsUpdate(chatId, [target], 'demote');
    await sock.sendMessage(chatId, { text: `✅ @${target.split('@')[0]} diturunkan jadi anggota biasa`, mentions: [target] });
  },
};

const groupInfoCommand = {
  name: 'groupinfo',
  aliases: ['infogrup'],
  description: 'Info grup saat ini',
  async execute({ sock, msg }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini hanya bisa dipakai di grup.' }, { quoted: msg });
      return;
    }
    const metadata = await sock.groupMetadata(chatId);
    const admins = metadata.participants.filter((p) => p.admin).length;
    const text = `📋 *Info Grup*
Nama: ${metadata.subject}
Jumlah anggota: ${metadata.participants.length}
Jumlah admin: ${admins}
Deskripsi: ${metadata.desc || '(tidak ada)'}`;
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};

module.exports = { tagallCommand, kickCommand, promoteCommand, demoteCommand, groupInfoCommand, isSenderAdmin };
