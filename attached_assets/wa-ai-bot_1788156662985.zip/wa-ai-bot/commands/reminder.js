module.exports = {
  name: 'reminder',
  aliases: ['ingatkan', 'remindme'],
  description: 'Pasang pengingat. Contoh: .reminder 10 minum air',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const minutes = parseFloat(args[0]);
    const note = args.slice(1).join(' ').trim();

    if (!minutes || minutes <= 0 || !note) {
      await sock.sendMessage(
        chatId,
        { text: 'Format: .reminder <menit> <pesan>\nContoh: .reminder 15 meeting sama tim' },
        { quoted: msg }
      );
      return;
    }

    if (minutes > 1440) {
      await sock.sendMessage(chatId, { text: '❌ Maksimal pengingat 1440 menit (24 jam).' }, { quoted: msg });
      return;
    }

    await sock.sendMessage(
      chatId,
      { text: `⏰ Oke, aku ingatkan "${note}" dalam ${minutes} menit lagi.` },
      { quoted: msg }
    );

    setTimeout(async () => {
      try {
        await sock.sendMessage(chatId, {
          text: `🔔 *Pengingat!*\n${note}`,
        });
      } catch (err) {
        console.error('Gagal mengirim reminder:', err);
      }
    }, minutes * 60 * 1000);
  },
};
