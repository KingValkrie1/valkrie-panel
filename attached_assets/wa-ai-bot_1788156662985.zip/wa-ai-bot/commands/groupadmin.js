const { isSenderAdmin } = require('./group');

async function requireGroupAdmin(sock, msg, sender) {
  const chatId = msg.key.remoteJid;
  if (!chatId.endsWith('@g.us')) {
    await sock.sendMessage(chatId, { text: '❌ Perintah ini hanya bisa dipakai di grup.' }, { quoted: msg });
    return false;
  }
  if (!(await isSenderAdmin(sock, chatId, sender))) {
    await sock.sendMessage(chatId, { text: '❌ Hanya admin grup yang bisa pakai perintah ini.' }, { quoted: msg });
    return false;
  }
  return true;
}

const setNameCommand = {
  name: 'setname',
  aliases: ['namagrup'],
  description: '[Admin] Ganti nama grup. Contoh: .setname Grup Seru',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const name = args.join(' ').trim();
    if (!name) {
      await sock.sendMessage(chatId, { text: 'Contoh: .setname Grup Seru Selamanya' }, { quoted: msg });
      return;
    }
    await sock.groupUpdateSubject(chatId, name);
    await sock.sendMessage(chatId, { text: `✅ Nama grup diganti jadi "${name}"` }, { quoted: msg });
  },
};

const setDescCommand = {
  name: 'setdesc',
  aliases: ['deskripsigrup'],
  description: '[Admin] Ganti deskripsi grup',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const desc = args.join(' ').trim();
    if (!desc) {
      await sock.sendMessage(chatId, { text: 'Contoh: .setdesc Grup diskusi santai seputar teknologi' }, { quoted: msg });
      return;
    }
    await sock.groupUpdateDescription(chatId, desc);
    await sock.sendMessage(chatId, { text: '✅ Deskripsi grup diperbarui.' }, { quoted: msg });
  },
};

const closeCommand = {
  name: 'close',
  aliases: ['kunci', 'lockgroup'],
  description: '[Admin] Kunci grup — hanya admin yang bisa kirim pesan',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    await sock.groupSettingUpdate(chatId, 'announcement');
    await sock.sendMessage(chatId, { text: '🔒 Grup dikunci. Hanya admin yang bisa kirim pesan sekarang.' }, { quoted: msg });
  },
};

const openCommand = {
  name: 'open',
  aliases: ['buka', 'unlockgroup'],
  description: '[Admin] Buka grup — semua anggota bisa kirim pesan lagi',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    await sock.groupSettingUpdate(chatId, 'not_announcement');
    await sock.sendMessage(chatId, { text: '🔓 Grup dibuka. Semua anggota bisa kirim pesan lagi.' }, { quoted: msg });
  },
};

const linkCommand = {
  name: 'link',
  aliases: ['invitelink', 'linkgrup'],
  description: '[Admin] Dapatkan link undangan grup',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const code = await sock.groupInviteCode(chatId);
    await sock.sendMessage(chatId, { text: `🔗 https://chat.whatsapp.com/${code}` }, { quoted: msg });
  },
};

const revokeCommand = {
  name: 'revoke',
  aliases: ['resetlink'],
  description: '[Admin] Reset link undangan grup (link lama jadi tidak berlaku)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const code = await sock.groupRevokeInvite(chatId);
    await sock.sendMessage(chatId, { text: `✅ Link lama direset.\n🔗 Link baru: https://chat.whatsapp.com/${code}` }, { quoted: msg });
  },
};

const delCommand = {
  name: 'del',
  aliases: ['hapuspesan'],
  description: '[Admin] Hapus pesan (reply pesan yang mau dihapus)',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!(await requireGroupAdmin(sock, msg, sender))) return;
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    if (!ctx?.stanzaId) {
      await sock.sendMessage(chatId, { text: 'Reply pesan yang mau dihapus dengan .del' }, { quoted: msg });
      return;
    }
    await sock.sendMessage(chatId, {
      delete: {
        remoteJid: chatId,
        fromMe: false,
        id: ctx.stanzaId,
        participant: ctx.participant,
      },
    });
  },
};

module.exports = {
  setNameCommand,
  setDescCommand,
  closeCommand,
  openCommand,
  linkCommand,
  revokeCommand,
  delCommand,
  requireGroupAdmin,
};
