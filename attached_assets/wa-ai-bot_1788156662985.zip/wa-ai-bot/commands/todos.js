const db = require('../lib/db');

function getTodos(chatId) {
  const all = db.read('todos', {});
  return all[chatId] || [];
}

function saveTodos(chatId, todos) {
  const all = db.read('todos', {});
  all[chatId] = todos;
  db.write('todos', all);
}

module.exports = {
  name: 'todo',
  aliases: ['tugas'],
  description: 'Daftar tugas. .todo tambah <teks> | .todo list | .todo selesai <no> | .todo hapus <no>',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const sub = (args[0] || '').toLowerCase();

    if (sub === 'tambah' || sub === 'add') {
      const text = args.slice(1).join(' ').trim();
      if (!text) {
        await sock.sendMessage(chatId, { text: 'Contoh: .todo tambah kerjain laporan' }, { quoted: msg });
        return;
      }
      const todos = getTodos(chatId);
      todos.push({ text, done: false, createdAt: new Date().toISOString() });
      saveTodos(chatId, todos);
      await sock.sendMessage(chatId, { text: `✅ Tugas ditambahkan (total: ${todos.length})` }, { quoted: msg });
      return;
    }

    if (sub === 'selesai' || sub === 'done') {
      const no = parseInt(args[1], 10);
      const todos = getTodos(chatId);
      if (!no || no < 1 || no > todos.length) {
        await sock.sendMessage(chatId, { text: '❌ Nomor tugas tidak valid. Cek .todo list dulu.' }, { quoted: msg });
        return;
      }
      todos[no - 1].done = true;
      saveTodos(chatId, todos);
      await sock.sendMessage(chatId, { text: `🎉 Mantap! "${todos[no - 1].text}" ditandai selesai.` }, { quoted: msg });
      return;
    }

    if (sub === 'hapus' || sub === 'delete') {
      const no = parseInt(args[1], 10);
      const todos = getTodos(chatId);
      if (!no || no < 1 || no > todos.length) {
        await sock.sendMessage(chatId, { text: '❌ Nomor tugas tidak valid. Cek .todo list dulu.' }, { quoted: msg });
        return;
      }
      const removed = todos.splice(no - 1, 1);
      saveTodos(chatId, todos);
      await sock.sendMessage(chatId, { text: `🗑️ Tugas dihapus: "${removed[0].text}"` }, { quoted: msg });
      return;
    }

    // default: list
    const todos = getTodos(chatId);
    if (todos.length === 0) {
      await sock.sendMessage(
        chatId,
        { text: 'Belum ada tugas.\n\n.todo tambah <teks>\n.todo list\n.todo selesai <no>\n.todo hapus <no>' },
        { quoted: msg }
      );
      return;
    }
    const text = `✅ *Daftar Tugas:*\n\n${todos
      .map((t, i) => `${i + 1}. ${t.done ? '✔️' : '⬜'} ${t.text}`)
      .join('\n')}`;
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};
