module.exports = {
  name: 'poll',
  aliases: ['polling', 'voting'],
  description: 'Buat polling WhatsApp. Contoh: .poll Makan apa hari ini?|Nasi goreng|Bakso|Mie ayam',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const raw = args.join(' ');
    const parts = raw.split('|').map((p) => p.trim()).filter(Boolean);

    if (parts.length < 3) {
      await sock.sendMessage(
        chatId,
        {
          text:
            'Format: .poll <pertanyaan>|<opsi1>|<opsi2>|...\nMinimal 2 opsi.\nContoh: .poll Makan apa hari ini?|Nasi goreng|Bakso|Mie ayam',
        },
        { quoted: msg }
      );
      return;
    }

    const [question, ...options] = parts;
    if (options.length > 12) {
      await sock.sendMessage(chatId, { text: '❌ Maksimal 12 opsi.' }, { quoted: msg });
      return;
    }

    await sock.sendMessage(
      chatId,
      { poll: { name: question, values: options, selectableCount: 1 } },
      { quoted: msg }
    );
  },
};
