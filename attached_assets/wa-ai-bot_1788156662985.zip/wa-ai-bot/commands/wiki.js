module.exports = {
  name: 'wiki',
  aliases: ['wikipedia'],
  description: 'Cari ringkasan artikel Wikipedia. Contoh: .wiki Indonesia',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const query = args.join(' ').trim();

    if (!query) {
      await sock.sendMessage(chatId, { text: 'Contoh: .wiki Republik Indonesia' }, { quoted: msg });
      return;
    }

    try {
      const res = await fetch(
        `https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`
      );
      if (!res.ok) {
        await sock.sendMessage(chatId, { text: `❌ Artikel "${query}" tidak ditemukan.` }, { quoted: msg });
        return;
      }
      const data = await res.json();
      const text = `📖 *${data.title}*\n\n${data.extract}\n\n🔗 ${data.content_urls?.desktop?.page || ''}`;
      await sock.sendMessage(chatId, { text }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal mencari: ${err.message}` }, { quoted: msg });
    }
  },
};
