module.exports = {
  name: 'cuaca',
  aliases: ['weather'],
  description: 'Cek cuaca kota tertentu',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const city = args.join(' ').trim();

    if (!city) {
      await sock.sendMessage(chatId, { text: 'Contoh: .cuaca Jakarta' }, { quoted: msg });
      return;
    }

    try {
      const res = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
      if (!res.ok) throw new Error(`status ${res.status}`);
      const data = await res.json();
      const cur = data.current_condition[0];
      const area = data.nearest_area[0];
      const namaKota = `${area.areaName[0].value}, ${area.country[0].value}`;

      const text = `🌤️ *Cuaca di ${namaKota}*
Kondisi: ${cur.weatherDesc[0].value}
Suhu: ${cur.temp_C}°C (terasa ${cur.FeelsLikeC}°C)
Kelembapan: ${cur.humidity}%
Angin: ${cur.windspeedKmph} km/jam`;

      await sock.sendMessage(chatId, { text }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal mengambil data cuaca: ${err.message}` }, { quoted: msg });
    }
  },
};
