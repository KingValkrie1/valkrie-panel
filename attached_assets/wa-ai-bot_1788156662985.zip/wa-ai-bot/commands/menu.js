const config = require('../config');

module.exports = {
  name: 'menu',
  aliases: ['help'],
  description: 'Menampilkan daftar perintah',
  async execute({ sock, msg, sender }) {
    const p = config.prefix;
    const text = `🤖 *WA AI BOT*
Halo! Berikut daftar perintah yang tersedia:

*🧠 AI*
${p}ai <pertanyaan> - Ngobrol dengan AI
${p}resetai - Reset riwayat obrolan AI

*🛠️ Utilitas*
${p}sticker (kirim/reply gambar atau video pendek) - Buat stiker
${p}toimg (reply stiker) - Ubah stiker jadi gambar
${p}tr <kode_bahasa> <teks> - Terjemahkan teks (contoh: ${p}tr en halo semua)
${p}calc <ekspresi> - Kalkulator (contoh: ${p}calc 12*7-3)
${p}quote - Kutipan acak
${p}ping - Cek kecepatan respons bot

*🌍 Info & Data*
${p}cuaca <kota> - Cek cuaca
${p}wiki <topik> - Ringkasan Wikipedia
${p}kurs <jumlah> <dari> <ke> - Konversi mata uang (contoh: ${p}kurs 100 USD IDR)

*⏰ Jadwal & Produktivitas*
${p}jadwal <waktu> | <pesan> - Jadwalkan pengingat (contoh: ${p}jadwal besok jam 8 | minum obat)
${p}jadwal list - Lihat jadwal aktif
${p}jadwal hapus <id> - Batalkan jadwal
${p}note tambah/list/hapus - Catatan
${p}todo tambah/list/selesai/hapus - Daftar tugas
${p}autoreply set/on/off - Balasan otomatis saat kamu sibuk

*🎉 Hiburan & Umum (semua orang boleh pakai)*
${p}meme - Meme random
${p}fakta - Fakta unik random
${p}pantun - Pantun random
${p}umur <DD-MM-YYYY> - Hitung umur
${p}zodiak <DD-MM> - Cek zodiak
${p}pass <panjang> - Generate password
${p}pilih <opsi1>|<opsi2> - Pilih random dari beberapa opsi
${p}dadu / ${p}koin - Lempar dadu/koin

*🔧 Alat*
${p}qr <teks/link> - Buat QR code
${p}short <url> - Perpendek URL
${p}poll <pertanyaan>|<opsi1>|<opsi2> - Buat polling WA

*👥 Grup (khusus admin)*
${p}tagall [pesan] - Mention semua anggota
${p}kick / ${p}promote / ${p}demote (reply/mention)
${p}warn (reply/mention) [alasan] - Beri peringatan (3x = auto-kick)
${p}resetwarn (reply/mention) - Reset peringatan
${p}del (reply pesan) - Hapus pesan siapapun
${p}antilink on/off - Hapus otomatis pesan berisi link
${p}close / ${p}open - Kunci/buka grup
${p}setname <nama> / ${p}setdesc <teks> - Ganti nama/deskripsi grup
${p}link / ${p}revoke - Link undangan grup / reset link
${p}setwelcome <teks> / ${p}setgoodbye <teks> - Custom pesan sambutan (pakai {user} {group})
${p}groupinfo - Info grup

*👑 Khusus Owner Bot*
${p}broadcast <pesan> - Kirim pesan ke semua grup
${p}listgrup - Daftar grup yang diikuti bot
${p}block / ${p}unblock (reply/mention/nomor) - Blokir orang dari pakai bot
${p}listblock - Daftar nomor yang diblokir
${p}setprefix <karakter> - Ganti prefix bot
${p}stats - Statistik bot

*ℹ️ Info*
${p}owner - Info pemilik bot
${p}menu - Menampilkan menu ini

Kirim perintah tanpa spasi ekstra, prefix: "${p}"`;
    await sock.sendMessage(msg.key.remoteJid, { text }, { quoted: msg });
  },
};
