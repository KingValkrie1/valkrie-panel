const db = require('../lib/db');

function getNotes(chatId) {
  const all = db.read('notes', {});
  return all[chatId] || [];
}

function saveNotes(chatId, notes) {
  const all = db.read('notes', {});
  all[chatId] = notes;
  db.write('notes', all);
}

module.exports = {
  name: 'note',
  aliases: ['catatan'],
  description: 'Simpan catatan. .note tambah <teks> | .note list | .note hapus <no>',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const sub = (args[0] || '').toLowerCase();

    if (sub === 'tambah' || sub === 'add') {
      const text = args.slice(1).join(' ').trim();
      if (!text) {
        await sock.sendMessage(chatId, { text: 'Contoh: .note tambah beli galon' }, { quoted: msg });
        return;
      }
      const notes = getNotes(chatId);
      notes.push({ text, createdAt: new Date().toISOString() });
      saveNotes(chatId, notes);
      await sock.sendMessage(chatId, { text: `✅ Catatan disimpan (total: ${notes.length})` }, { quoted: msg });
      return;
    }

    if (sub === 'hapus' || sub === 'delete') {
      const no = parseInt(args[1], 10);
      const notes = getNotes(chatId);
      if (!no || no < 1 || no > notes.length) {
        await sock.sendMessage(chatId, { text: '❌ Nomor catatan tidak valid. Cek .note list dulu.' }, { quoted: msg });
        return;
      }
      const removed = notes.splice(no - 1, 1);
      saveNotes(chatId, notes);
      await sock.sendMessage(chatId, { text: `🗑️ Catatan dihapus: "${removed[0].text}"` }, { quoted: msg });
      return;
    }

    // default: list
    const notes = getNotes(chatId);
    if (notes.length === 0) {
      await sock.sendMessage(
        chatId,
        { text: 'Belum ada catatan.\n\n.note tambah <teks>\n.note list\n.note hapus <no>' },
        { quoted: msg }
      );
      return;
    }
    const text = `📝 *Catatan di chat ini:*\n\n${notes.map((n, i) => `${i + 1}. ${n.text}`).join('\n')}`;
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};
