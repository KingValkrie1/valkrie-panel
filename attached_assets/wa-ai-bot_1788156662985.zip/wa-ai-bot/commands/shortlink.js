module.exports = {
  name: 'short',
  aliases: ['shortlink', 'pendekin'],
  description: 'Perpendek URL. Contoh: .short https://contoh.com/link-panjang',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const url = args[0];

    if (!url || !/^https?:\/\//.test(url)) {
      await sock.sendMessage(chatId, { text: 'Contoh: .short https://contoh.com/link-yang-panjang' }, { quoted: msg });
      return;
    }

    try {
      const res = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
      const shortUrl = await res.text();
      if (shortUrl.startsWith('Error')) throw new Error(shortUrl);
      await sock.sendMessage(chatId, { text: `🔗 ${shortUrl}` }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal memperpendek URL: ${err.message}` }, { quoted: msg });
    }
  },
};
