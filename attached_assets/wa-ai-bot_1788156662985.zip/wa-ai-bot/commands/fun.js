const pantunList = [
  'Jalan-jalan ke kota Blitar\nJangan lupa membeli container\nJangan pernah kau menyerah\nKarena hidup harus terus berjalan',
  'Beli baju di pasar Minggu\nJangan lupa beli topi\nKalau kamu rindu aku\nBilang aja jangan sembunyi',
  'Ke pasar membeli ikan\nIkan segar banyak pembeli\nKerja keras jangan dilupakan\nKarena hasil takkan mengkhianati',
  'Air jernih di dalam gelas\nDiminum saat cuaca panas\nJadi orang harus ikhlas\nBiar hidup selalu lapang dada',
  'Buah manggis buah duku\nDibawa pulang naik sepeda\nBelajar terus jangan ragu\nKarena ilmu tak pernah sia-sia',
];

const factsFallback = [
  'Madu adalah satu-satunya makanan yang tidak pernah basi jika disimpan dengan benar.',
  'Jantung udang terletak di kepalanya.',
  'Satu hari di planet Venus lebih lama daripada satu tahunnya.',
  'Bank sperma? Bukan, ini fakta: Gurita punya tiga jantung dan darah berwarna biru.',
  'Bintang laut tidak punya otak.',
];

const pantunCommand = {
  name: 'pantun',
  aliases: [],
  description: 'Pantun random',
  async execute({ sock, msg }) {
    const p = pantunList[Math.floor(Math.random() * pantunList.length)];
    await sock.sendMessage(msg.key.remoteJid, { text: `📜 *Pantun:*\n\n${p}` }, { quoted: msg });
  },
};

const factCommand = {
  name: 'fakta',
  aliases: ['fact'],
  description: 'Fakta unik random',
  async execute({ sock, msg }) {
    const chatId = msg.key.remoteJid;
    try {
      const res = await fetch('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
      if (!res.ok) throw new Error('gagal fetch');
      const data = await res.json();
      await sock.sendMessage(chatId, { text: `🧠 *Fakta unik:*\n${data.text}` }, { quoted: msg });
    } catch {
      const f = factsFallback[Math.floor(Math.random() * factsFallback.length)];
      await sock.sendMessage(chatId, { text: `🧠 *Fakta unik:*\n${f}` }, { quoted: msg });
    }
  },
};

const memeCommand = {
  name: 'meme',
  aliases: [],
  description: 'Meme random',
  async execute({ sock, msg }) {
    const chatId = msg.key.remoteJid;
    try {
      const res = await fetch('https://meme-api.com/gimme');
      if (!res.ok) throw new Error('gagal fetch meme');
      const data = await res.json();
      await sock.sendMessage(chatId, { image: { url: data.url }, caption: `😂 ${data.title}` }, { quoted: msg });
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal ambil meme: ${err.message}` }, { quoted: msg });
    }
  },
};

const umurCommand = {
  name: 'umur',
  aliases: ['age'],
  description: 'Hitung umur. Contoh: .umur 17-08-1998',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const m = (args[0] || '').match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
    if (!m) {
      await sock.sendMessage(chatId, { text: 'Format: .umur DD-MM-YYYY\nContoh: .umur 17-08-1998' }, { quoted: msg });
      return;
    }
    const [, d, mo, y] = m.map(Number);
    const lahir = new Date(y, mo - 1, d);
    if (isNaN(lahir.getTime())) {
      await sock.sendMessage(chatId, { text: '❌ Tanggal tidak valid.' }, { quoted: msg });
      return;
    }
    const now = new Date();
    let years = now.getFullYear() - lahir.getFullYear();
    let months = now.getMonth() - lahir.getMonth();
    let days = now.getDate() - lahir.getDate();
    if (days < 0) {
      months -= 1;
      days += new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }
    await sock.sendMessage(chatId, { text: `🎂 Umur kamu: ${years} tahun, ${months} bulan, ${days} hari` }, { quoted: msg });
  },
};

const zodiakCommand = {
  name: 'zodiak',
  aliases: ['zodiac'],
  description: 'Cek zodiak dari tanggal lahir. Contoh: .zodiak 17-08',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const m = (args[0] || '').match(/^(\d{1,2})-(\d{1,2})$/);
    if (!m) {
      await sock.sendMessage(chatId, { text: 'Format: .zodiak DD-MM\nContoh: .zodiak 17-08' }, { quoted: msg });
      return;
    }
    const day = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);

    function getZodiak(d, mo) {
      if ((mo === 3 && d >= 21) || (mo === 4 && d <= 19)) return 'Aries';
      if ((mo === 4 && d >= 20) || (mo === 5 && d <= 20)) return 'Taurus';
      if ((mo === 5 && d >= 21) || (mo === 6 && d <= 20)) return 'Gemini';
      if ((mo === 6 && d >= 21) || (mo === 7 && d <= 22)) return 'Cancer';
      if ((mo === 7 && d >= 23) || (mo === 8 && d <= 22)) return 'Leo';
      if ((mo === 8 && d >= 23) || (mo === 9 && d <= 22)) return 'Virgo';
      if ((mo === 9 && d >= 23) || (mo === 10 && d <= 22)) return 'Libra';
      if ((mo === 10 && d >= 23) || (mo === 11 && d <= 21)) return 'Scorpio';
      if ((mo === 11 && d >= 22) || (mo === 12 && d <= 21)) return 'Sagittarius';
      if ((mo === 12 && d >= 22) || (mo === 1 && d <= 19)) return 'Capricorn';
      if ((mo === 1 && d >= 20) || (mo === 2 && d <= 18)) return 'Aquarius';
      return 'Pisces';
    }

    await sock.sendMessage(chatId, { text: `♈ Zodiak kamu: *${getZodiak(day, month)}*` }, { quoted: msg });
  },
};

const passCommand = {
  name: 'pass',
  aliases: ['password', 'genpass'],
  description: 'Generate password random. Contoh: .pass 12',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    let length = parseInt(args[0], 10) || 12;
    length = Math.min(Math.max(length, 4), 64);
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let pass = '';
    for (let i = 0; i < length; i++) pass += chars[Math.floor(Math.random() * chars.length)];
    await sock.sendMessage(chatId, { text: `🔐 Password (${length} karakter):\n\`\`\`${pass}\`\`\`` }, { quoted: msg });
  },
};

const pilihCommand = {
  name: 'pilih',
  aliases: ['choose', 'random'],
  description: 'Pilih random dari beberapa opsi. Contoh: .pilih makan nasi|makan mie|puasa',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const options = args.join(' ').split('|').map((o) => o.trim()).filter(Boolean);
    if (options.length < 2) {
      await sock.sendMessage(chatId, { text: 'Contoh: .pilih makan nasi|makan mie|puasa dulu' }, { quoted: msg });
      return;
    }
    const chosen = options[Math.floor(Math.random() * options.length)];
    await sock.sendMessage(chatId, { text: `🎯 Pilihan: *${chosen}*` }, { quoted: msg });
  },
};

const diceCommand = {
  name: 'dadu',
  aliases: ['dice'],
  description: 'Lempar dadu (1-6)',
  async execute({ sock, msg }) {
    const result = Math.floor(Math.random() * 6) + 1;
    await sock.sendMessage(msg.key.remoteJid, { text: `🎲 Hasil dadu: *${result}*` }, { quoted: msg });
  },
};

const coinCommand = {
  name: 'koin',
  aliases: ['coinflip', 'flip'],
  description: 'Lempar koin (angka/gambar)',
  async execute({ sock, msg }) {
    const result = Math.random() < 0.5 ? 'Angka' : 'Gambar';
    await sock.sendMessage(msg.key.remoteJid, { text: `🪙 Hasil: *${result}*` }, { quoted: msg });
  },
};

module.exports = {
  pantunCommand,
  factCommand,
  memeCommand,
  umurCommand,
  zodiakCommand,
  passCommand,
  pilihCommand,
  diceCommand,
  coinCommand,
};
