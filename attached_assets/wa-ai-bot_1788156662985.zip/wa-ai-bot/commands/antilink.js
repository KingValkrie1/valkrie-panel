const { isSenderAdmin } = require('./group');

// State sederhana per grup (hilang saat bot restart)
const antilinkEnabled = new Set();
const linkRegex = /(https?:\/\/|chat\.whatsapp\.com|wa\.me)/i;

const antilinkCommand = {
  name: 'antilink',
  aliases: [],
  description: 'Aktif/nonaktifkan penghapusan otomatis pesan berisi link (khusus admin). Contoh: .antilink on',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!chatId.endsWith('@g.us')) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini hanya bisa dipakai di grup.' }, { quoted: msg });
      return;
    }
    if (!(await isSenderAdmin(sock, chatId, sender))) {
      await sock.sendMessage(chatId, { text: '❌ Hanya admin grup yang bisa pakai perintah ini.' }, { quoted: msg });
      return;
    }

    const mode = (args[0] || '').toLowerCase();
    if (mode === 'on') {
      antilinkEnabled.add(chatId);
      await sock.sendMessage(chatId, { text: '✅ Antilink diaktifkan. Pesan berisi link akan otomatis dihapus.' }, { quoted: msg });
    } else if (mode === 'off') {
      antilinkEnabled.delete(chatId);
      await sock.sendMessage(chatId, { text: '✅ Antilink dinonaktifkan.' }, { quoted: msg });
    } else {
      await sock.sendMessage(chatId, { text: 'Format: .antilink on / .antilink off' }, { quoted: msg });
    }
  },
};

// Dipanggil dari index.js untuk setiap pesan masuk di grup, sebelum/di luar pengecekan command
async function handleAntilink(sock, msg, text) {
  const chatId = msg.key.remoteJid;
  if (!chatId.endsWith('@g.us')) return false;
  if (!antilinkEnabled.has(chatId)) return false;
  if (!linkRegex.test(text)) return false;

  try {
    const sender = msg.key.participant || msg.key.remoteJid;
    if (await isSenderAdmin(sock, chatId, sender)) return false; // admin boleh kirim link

    await sock.sendMessage(chatId, { delete: msg.key });
    await sock.sendMessage(chatId, {
      text: `🚫 Pesan dari @${sender.split('@')[0]} dihapus karena mengandung link.`,
      mentions: [sender],
    });
    return true;
  } catch (err) {
    console.error('Gagal menghapus pesan antilink:', err);
    return false;
  }
}

module.exports = { antilinkCommand, handleAntilink };
