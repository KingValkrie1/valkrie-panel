const { isOwner, blockUser, unblockUser, getBlocked, normalizeNumber } = require('../lib/permissions');
const { setPrefix, getPrefix } = require('../lib/settings');

function ownerOnlyGuard(sender) {
  return isOwner(sender);
}

const broadcastCommand = {
  name: 'broadcast',
  aliases: ['bc'],
  description: '[Owner] Kirim pesan ke semua grup yang diikuti bot',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const text = args.join(' ').trim();
    if (!text) {
      await sock.sendMessage(chatId, { text: 'Contoh: .broadcast Pengumuman: bot sedang maintenance jam 10 malam' }, { quoted: msg });
      return;
    }

    const allGroups = await sock.groupFetchAllParticipating();
    const groupIds = Object.keys(allGroups);
    let success = 0;

    for (const gid of groupIds) {
      try {
        await sock.sendMessage(gid, { text: `📢 *Broadcast dari Owner*\n\n${text}` });
        success++;
        await new Promise((r) => setTimeout(r, 1000)); // jeda biar tidak dianggap spam
      } catch (err) {
        console.error(`Gagal broadcast ke ${gid}:`, err.message);
      }
    }

    await sock.sendMessage(chatId, { text: `✅ Broadcast terkirim ke ${success}/${groupIds.length} grup.` }, { quoted: msg });
  },
};

const listGroupCommand = {
  name: 'listgrup',
  aliases: ['listgroup'],
  description: '[Owner] Lihat semua grup yang diikuti bot',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const allGroups = await sock.groupFetchAllParticipating();
    const list = Object.values(allGroups);
    const text = `📋 *Grup yang diikuti bot (${list.length}):*\n\n${list
      .map((g, i) => `${i + 1}. ${g.subject} (${g.participants.length} anggota)`)
      .join('\n')}`;
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};

const blockCommand = {
  name: 'block',
  aliases: ['blokir'],
  description: '[Owner] Blokir nomor dari memakai bot. Reply/mention orangnya atau .block 6281234567890',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
    const target = mentioned || quotedParticipant || args[0];

    if (!target) {
      await sock.sendMessage(chatId, { text: 'Contoh: .block 6281234567890 (atau reply/mention orangnya)' }, { quoted: msg });
      return;
    }
    const num = blockUser(target);
    await sock.sendMessage(chatId, { text: `🚫 Nomor ${num} diblokir dari memakai bot.` }, { quoted: msg });
  },
};

const unblockCommand = {
  name: 'unblock',
  aliases: ['bukablokir'],
  description: '[Owner] Buka blokir nomor. .unblock 6281234567890',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const target = mentioned || args[0];
    if (!target) {
      await sock.sendMessage(chatId, { text: 'Contoh: .unblock 6281234567890' }, { quoted: msg });
      return;
    }
    const ok = unblockUser(target);
    await sock.sendMessage(chatId, { text: ok ? '✅ Nomor dibuka blokirnya.' : '❌ Nomor itu tidak sedang diblokir.' }, { quoted: msg });
  },
};

const listBlockedCommand = {
  name: 'listblock',
  aliases: ['listblokir'],
  description: '[Owner] Lihat daftar nomor yang diblokir',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const blocked = getBlocked();
    const text = blocked.length
      ? `🚫 *Nomor yang diblokir:*\n${blocked.map((n, i) => `${i + 1}. ${n}`).join('\n')}`
      : 'Tidak ada nomor yang diblokir.';
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};

const setPrefixCommand = {
  name: 'setprefix',
  aliases: [],
  description: '[Owner] Ganti prefix perintah bot. Contoh: .setprefix !',
  async execute({ sock, msg, args, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const newPrefix = args[0];
    if (!newPrefix || newPrefix.length > 3) {
      await sock.sendMessage(chatId, { text: `Prefix sekarang: "${getPrefix()}"\nContoh ganti: .setprefix !` }, { quoted: msg });
      return;
    }
    setPrefix(newPrefix);
    await sock.sendMessage(chatId, { text: `✅ Prefix diganti jadi "${newPrefix}". Mulai sekarang perintah pakai "${newPrefix}menu" dst.` }, { quoted: msg });
  },
};

const statsCommand = {
  name: 'stats',
  aliases: ['botinfo'],
  description: '[Owner] Statistik bot',
  async execute({ sock, msg, sender }) {
    const chatId = msg.key.remoteJid;
    if (!ownerOnlyGuard(sender)) {
      await sock.sendMessage(chatId, { text: '❌ Perintah ini khusus owner bot.' }, { quoted: msg });
      return;
    }
    const allGroups = await sock.groupFetchAllParticipating();
    const uptimeSec = process.uptime();
    const h = Math.floor(uptimeSec / 3600);
    const m = Math.floor((uptimeSec % 3600) / 60);
    const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);

    const text = `📊 *Statistik Bot*
Jumlah grup: ${Object.keys(allGroups).length}
Uptime: ${h}j ${m}m
Memori dipakai: ${mem} MB
Prefix aktif: ${getPrefix()}`;
    await sock.sendMessage(chatId, { text }, { quoted: msg });
  },
};

module.exports = {
  broadcastCommand,
  listGroupCommand,
  blockCommand,
  unblockCommand,
  listBlockedCommand,
  setPrefixCommand,
  statsCommand,
};
