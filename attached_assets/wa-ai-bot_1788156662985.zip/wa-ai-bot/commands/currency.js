module.exports = {
  name: 'kurs',
  aliases: ['convert', 'currency'],
  description: 'Konversi mata uang. Contoh: .kurs 100 USD IDR',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const [amountStr, from, to] = args;
    const amount = parseFloat(amountStr);

    if (!amount || !from || !to) {
      await sock.sendMessage(chatId, { text: 'Format: .kurs <jumlah> <dari> <ke>\nContoh: .kurs 100 USD IDR' }, { quoted: msg });
      return;
    }

    try {
      const res = await fetch(`https://open.er-api.com/v6/latest/${from.toUpperCase()}`);
      const data = await res.json();
      if (data.result !== 'success') throw new Error('kode mata uang tidak valid');

      const rate = data.rates[to.toUpperCase()];
      if (!rate) throw new Error(`kode mata uang "${to}" tidak ditemukan`);

      const result = (amount * rate).toLocaleString('id-ID', { maximumFractionDigits: 2 });
      await sock.sendMessage(
        chatId,
        { text: `💱 ${amount} ${from.toUpperCase()} = *${result} ${to.toUpperCase()}*` },
        { quoted: msg }
      );
    } catch (err) {
      await sock.sendMessage(chatId, { text: `❌ Gagal konversi: ${err.message}` }, { quoted: msg });
    }
  },
};
