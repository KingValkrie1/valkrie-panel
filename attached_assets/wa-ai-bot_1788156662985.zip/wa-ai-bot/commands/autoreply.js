const db = require('../lib/db');

function getConfig() {
  return db.read('autoreply', { enabled: false, message: '' });
}

function saveConfig(cfg) {
  db.write('autoreply', cfg);
}

const autoreplyCommand = {
  name: 'autoreply',
  aliases: ['autobalas'],
  description: 'Atur balasan otomatis saat kamu sedang tidak aktif. .autoreply set <pesan> | .autoreply on/off',
  async execute({ sock, msg, args }) {
    const chatId = msg.key.remoteJid;
    const sub = (args[0] || '').toLowerCase();

    if (sub === 'set') {
      const text = args.slice(1).join(' ').trim();
      if (!text) {
        await sock.sendMessage(chatId, { text: 'Contoh: .autoreply set Lagi sibuk, nanti dibalas ya!' }, { quoted: msg });
        return;
      }
      const cfg = getConfig();
      cfg.message = text;
      saveConfig(cfg);
      await sock.sendMessage(chatId, { text: '✅ Pesan auto-reply disimpan.' }, { quoted: msg });
      return;
    }

    if (sub === 'on' || sub === 'off') {
      const cfg = getConfig();
      cfg.enabled = sub === 'on';
      if (cfg.enabled && !cfg.message) {
        await sock.sendMessage(chatId, { text: '❌ Set dulu pesannya: .autoreply set <pesan>' }, { quoted: msg });
        return;
      }
      saveConfig(cfg);
      await sock.sendMessage(chatId, { text: `✅ Auto-reply ${cfg.enabled ? 'diaktifkan' : 'dinonaktifkan'}.` }, { quoted: msg });
      return;
    }

    const cfg = getConfig();
    await sock.sendMessage(
      chatId,
      {
        text: `⚙️ *Status Auto-reply*\nAktif: ${cfg.enabled ? 'Ya' : 'Tidak'}\nPesan: ${cfg.message || '(belum diatur)'}\n\n.autoreply set <pesan>\n.autoreply on\n.autoreply off`,
      },
      { quoted: msg }
    );
  },
};

// Dipanggil dari index.js untuk pesan pribadi yang bukan command
async function maybeAutoReply(sock, msg, chatId) {
  if (chatId.endsWith('@g.us')) return; // hanya untuk chat pribadi
  const cfg = getConfig();
  if (!cfg.enabled || !cfg.message) return;
  await sock.sendMessage(chatId, { text: cfg.message }, { quoted: msg });
}

module.exports = { autoreplyCommand, maybeAutoReply };
