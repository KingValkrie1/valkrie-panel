const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const pino = require('pino');
const qrcode = require('qrcode-terminal');

const config = require('./config');
const menuCommand = require('./commands/menu');
const aiCommand = require('./commands/ai');
const stickerCommand = require('./commands/sticker');
const translateCommand = require('./commands/translate');
const { pingCommand, calcCommand, quoteCommand, ownerCommand } = require('./commands/tools');
const weatherCommand = require('./commands/weather');
const reminderCommand = require('./commands/reminder');
const { tagallCommand, kickCommand, promoteCommand, demoteCommand, groupInfoCommand } = require('./commands/group');
const wikiCommand = require('./commands/wiki');
const currencyCommand = require('./commands/currency');
const qrCommand = require('./commands/qr');
const shortlinkCommand = require('./commands/shortlink');
const { antilinkCommand, handleAntilink } = require('./commands/antilink');
const { handleGroupParticipantsUpdate } = require('./lib/groupEvents');
const scheduleCommand = require('./commands/schedule');
const scheduler = require('./lib/scheduler');
const notesCommand = require('./commands/notes');
const todosCommand = require('./commands/todos');
const pollCommand = require('./commands/poll');
const { autoreplyCommand, maybeAutoReply } = require('./commands/autoreply');
const {
  broadcastCommand,
  listGroupCommand,
  blockCommand,
  unblockCommand,
  listBlockedCommand,
  setPrefixCommand,
  statsCommand,
} = require('./commands/owner-tools');
const {
  setNameCommand,
  setDescCommand,
  closeCommand,
  openCommand,
  linkCommand,
  revokeCommand,
  delCommand,
} = require('./commands/groupadmin');
const { warnCommand, resetWarnCommand } = require('./commands/warn');
const { setWelcomeCommand, setGoodbyeCommand } = require('./commands/welcomeconfig');
const {
  pantunCommand,
  factCommand,
  memeCommand,
  umurCommand,
  zodiakCommand,
  passCommand,
  pilihCommand,
  diceCommand,
  coinCommand,
} = require('./commands/fun');
const { isBlocked, isOwner } = require('./lib/permissions');
const { getPrefix } = require('./lib/settings');

// Daftarkan semua command di sini. Tambah command baru cukup push ke array ini.
const commands = [
  menuCommand,
  aiCommand,
  aiCommand.resetCommand,
  stickerCommand,
  stickerCommand.toImgCommand,
  translateCommand,
  pingCommand,
  calcCommand,
  quoteCommand,
  ownerCommand,
  weatherCommand,
  reminderCommand,
  tagallCommand,
  kickCommand,
  promoteCommand,
  demoteCommand,
  groupInfoCommand,
  wikiCommand,
  currencyCommand,
  qrCommand,
  shortlinkCommand,
  antilinkCommand,
  scheduleCommand,
  notesCommand,
  todosCommand,
  pollCommand,
  autoreplyCommand,
  broadcastCommand,
  listGroupCommand,
  blockCommand,
  unblockCommand,
  listBlockedCommand,
  setPrefixCommand,
  statsCommand,
  setNameCommand,
  setDescCommand,
  closeCommand,
  openCommand,
  linkCommand,
  revokeCommand,
  delCommand,
  warnCommand,
  resetWarnCommand,
  setWelcomeCommand,
  setGoodbyeCommand,
  pantunCommand,
  factCommand,
  memeCommand,
  umurCommand,
  zodiakCommand,
  passCommand,
  pilihCommand,
  diceCommand,
  coinCommand,
];

const commandMap = new Map();
for (const cmd of commands) {
  commandMap.set(cmd.name, cmd);
  for (const alias of cmd.aliases || []) commandMap.set(alias, cmd);
}

function extractText(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    ''
  );
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
  });

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log('Scan QR code berikut dengan WhatsApp kamu:');
      qrcode.generate(qr, { small: true });
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log('Koneksi terputus.', shouldReconnect ? 'Menyambung ulang...' : 'Logout, hapus folder auth_info untuk login ulang.');
      if (shouldReconnect) startBot();
    } else if (connection === 'open') {
      console.log('✅ Bot berhasil terhubung ke WhatsApp!');
      scheduler.init(sock);
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('group-participants.update', (event) => {
    handleGroupParticipantsUpdate(sock, event);
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const text = extractText(msg).trim();
    const sender = msg.key.participant || msg.key.remoteJid;

    // Nomor yang diblokir owner tidak bisa pakai bot sama sekali (kecuali owner sendiri)
    if (isBlocked(sender) && !isOwner(sender)) return;

    // Cek antilink dulu untuk semua pesan grup (bukan hanya yang diawali prefix)
    const wasDeleted = await handleAntilink(sock, msg, text);
    if (wasDeleted) return;

    const prefix = getPrefix();
    if (!text.startsWith(prefix)) {
      await maybeAutoReply(sock, msg, msg.key.remoteJid);
      return;
    }

    const withoutPrefix = text.slice(prefix.length).trim();
    const [cmdName, ...args] = withoutPrefix.split(/\s+/);
    const command = commandMap.get(cmdName.toLowerCase());
    if (!command) return;

    try {
      await command.execute({ sock, msg, args, sender });
    } catch (err) {
      console.error(`Error menjalankan command ${cmdName}:`, err);
      await sock.sendMessage(
        msg.key.remoteJid,
        { text: `❌ Terjadi kesalahan saat menjalankan perintah: ${err.message}` },
        { quoted: msg }
      );
    }
  });
}

startBot();
