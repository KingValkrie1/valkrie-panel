# WA AI Bot Multifungsi

Bot WhatsApp berbasis [Baileys](https://github.com/WhiskeySockets/Baileys) (tidak perlu WhatsApp Business API resmi, login via scan QR).

## Fitur

**Semua orang bisa pakai** (grup & pribadi):
- 🧠 Chat dengan AI (`.ai`), OpenAI-compatible
- 🖼️ Stiker (`.sticker`, `.toimg`)
- 🌐 Terjemahan (`.tr`) 🧮 Kalkulator (`.calc`) 🏓 Ping (`.ping`)
- 🌤️ Cuaca (`.cuaca`) 📖 Wikipedia (`.wiki`) 💱 Kurs mata uang (`.kurs`)
- ⏰ **Jadwal/pengingat pintar (`.jadwal`)** — "besok jam 8", "3 jam lagi", "setiap hari jam 7", dll. Tersimpan permanen
- 📝 Catatan (`.note`) ✅ To-do list (`.todo`)
- 📱 QR code (`.qr`) 🔗 Perpendek URL (`.short`) 🗳️ Polling (`.poll`)
- 😂 Meme (`.meme`) 🧠 Fakta unik (`.fakta`) 📜 Pantun (`.pantun`)
- 🎂 Hitung umur (`.umur`) ♈ Zodiak (`.zodiak`) 🔐 Generator password (`.pass`)
- 🎯 Pilih random (`.pilih`) 🎲 Dadu/koin (`.dadu`, `.koin`)
- 💤 Auto-reply saat sibuk (`.autoreply`, khusus chat pribadi)

**Khusus admin grup:**
- `.tagall`, `.kick`, `.promote`, `.demote`, `.groupinfo`
- `.warn` / `.resetwarn` — sistem peringatan, 3x warn = auto-kick
- `.del` — hapus pesan siapapun (reply pesannya)
- `.antilink on/off` — auto-hapus pesan berisi link
- `.close` / `.open` — kunci/buka grup
- `.setname`, `.setdesc` — ganti nama/deskripsi grup
- `.link`, `.revoke` — link undangan grup & reset link
- `.setwelcome`, `.setgoodbye` — custom pesan sambutan/perpisahan (pakai `{user}` `{group}`)
- Pesan selamat datang/perpisahan otomatis saat member masuk/keluar (default, bisa dikustom)

**Khusus owner bot** (diatur lewat `OWNER_NUMBER` di `.env`):
- `.broadcast` — kirim pesan ke semua grup yang diikuti bot
- `.listgrup` — daftar grup yang diikuti bot
- `.block` / `.unblock` / `.listblock` — blokir nomor tertentu dari memakai bot sama sekali
- `.setprefix` — ganti prefix bot secara global saat bot jalan (tanpa restart)
- `.stats` — statistik bot (uptime, jumlah grup, memori)

Mudah ditambah command baru — lihat bagian "Menambah Command" di bawah.

## Fitur Unggulan: Jadwal Pintar

Ini yang paling sering dipakai — kamu bisa suruh bot mengirim pesan/pengingat di masa depan pakai bahasa natural:

```
.jadwal besok jam 8 | jangan lupa meeting
.jadwal 3 jam lagi | angkat jemuran
.jadwal lusa | ambil paket di kantor pos
.jadwal senin jam 9 | mulai kerja
.jadwal setiap hari jam 6 | sholat subuh / olahraga pagi
.jadwal setiap senin jam 8 | rapat mingguan
.jadwal 31/12 jam 20:00 | tahun baruan
```

Semua jadwal **tersimpan di file `data/schedules.json`**, jadi kalau bot mati/restart, jadwal yang belum lewat tetap akan dijalankan begitu bot nyala lagi. Cek jadwal aktif dengan `.jadwal list`, batalkan dengan `.jadwal hapus <id>`.

## Penting Soal Owner & Admin

- **Owner bot** ditentukan dari `OWNER_NUMBER` di `.env` (isi nomor kamu sendiri, format `62xxxxxxxxxx`, tanpa "+" atau spasi). Cuma nomor ini yang bisa pakai perintah `.broadcast`, `.block`, `.setprefix`, dll.
- **Admin grup** dicek otomatis dari status admin WhatsApp di grup tersebut (bukan diatur manual) — jadi siapa pun yang kamu jadikan admin di WhatsApp otomatis bisa pakai perintah admin seperti `.kick`, `.warn`, `.close`, dll.
- Untuk perintah yang mengubah grup (`.kick`, `.close`, `.setname`, dll), **bot itu sendiri juga harus dijadikan admin** di grup tersebut, karena WhatsApp tidak mengizinkan aksi itu dari akun non-admin.

## Instalasi

1. Pastikan Node.js versi 18 ke atas sudah terpasang.
2. Extract folder ini, lalu masuk ke dalamnya:
   ```
   cd wa-ai-bot
   npm install
   ```
3. Salin `.env.example` menjadi `.env`, lalu isi `AI_API_KEY` dengan API key kamu (OpenAI/Groq/OpenRouter/dll):
   ```
   cp .env.example .env
   ```
4. Jalankan bot:
   ```
   npm start
   ```
5. Scan QR code yang muncul di terminal menggunakan WhatsApp di HP kamu:
   **WhatsApp > Perangkat Tertaut > Tautkan Perangkat**.
6. Setelah terhubung, coba kirim `.menu` ke chat pribadi bot (nomor yang login) atau ke grup yang berisi bot.

Sesi login akan tersimpan di folder `auth_info/` sehingga tidak perlu scan ulang setiap kali dijalankan (kecuali kamu logout dari HP atau hapus folder tersebut).

## Menambah Command Baru

1. Buat file baru di folder `commands/`, contoh `commands/cuaca.js`:
   ```js
   module.exports = {
     name: 'cuaca',
     aliases: [],
     description: 'Cek cuaca kota tertentu',
     async execute({ sock, msg, args }) {
       await sock.sendMessage(msg.key.remoteJid, { text: 'Fitur cuaca segera hadir!' }, { quoted: msg });
     },
   };
   ```
2. Import dan daftarkan di `index.js`, tambahkan ke array `commands`.
3. Restart bot.

## Catatan Penting
- Baileys adalah library tidak resmi. Gunakan dengan wajar (jangan spam massal) agar nomor tidak diblokir WhatsApp.
- Untuk pemakaian produksi/skala besar, pertimbangkan WhatsApp Business Cloud API resmi dari Meta.
- Ganti `AI_BASE_URL` dan `AI_MODEL` di `.env` sesuai provider AI yang kamu pakai.
